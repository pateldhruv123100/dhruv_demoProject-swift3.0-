//
//  listView.swift
//  IMHere24X7_Swift
//
//  Created by i mac meridian on 11/8/16.
//  Copyright © 2016 i mac meridian. All rights reserved.
//

import UIKit
import MBProgressHUD

class listView: UIViewController,UITableViewDelegate,UITableViewDataSource,UISearchBarDelegate,UISearchResultsUpdating{
    var dictData:NSArray = []
    
    var mainResult:NSMutableArray = []
    var searchResults:NSArray = []
    var resultSearchController = UISearchController()
    
    @IBOutlet weak var tblvw: UITableView!
    
   
    override func viewDidLoad() {
        super.viewDidLoad()
        WebServiceCall()
        
        resultSearchController = UISearchController(searchResultsController: nil)
        resultSearchController.searchResultsUpdater = self
        resultSearchController.hidesNavigationBarDuringPresentation = false
        resultSearchController.dimsBackgroundDuringPresentation = false
        tblvw.tableHeaderView = resultSearchController.searchBar
        
        let placeholderAttributes: [String : AnyObject] = [NSForegroundColorAttributeName: UIColor.gray, NSFontAttributeName: UIFont.systemFont(ofSize: UIFont.systemFontSize)]
        let attributedPlaceholder: NSAttributedString = NSAttributedString(string: "Search Vehicle Number", attributes: placeholderAttributes)
        let textFieldPlaceHolder = resultSearchController.searchBar.value(forKey: "searchField") as? UITextField
        textFieldPlaceHolder?.attributedPlaceholder = attributedPlaceholder
        
 
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    public func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        if (self.resultSearchController.isActive)
        {
            return searchResults.count;
        }
        else
        {
            return mainResult.count;
        }
        
    }
    
    public func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell{
        
        var cell = UITableViewCell()
        cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as UITableViewCell
        
        var lblVNumber = UILabel()
        var lblAddress = UILabel()
        
        lblVNumber  = cell.viewWithTag(100) as! UILabel
        lblAddress  = cell.viewWithTag(200) as! UILabel
        var  recipe :searchVehicleData
        if (self.resultSearchController.isActive)
        {
            recipe = searchResults[(indexPath as NSIndexPath).row] as! searchVehicleData
            
        }
        else
        {
            recipe = mainResult[(indexPath as NSIndexPath).row] as! searchVehicleData
            
        }
        
        lblVNumber.text = recipe.vehicleNumber as String
        lblAddress.text = recipe.Address as String
        
        
        return cell
        
    }
    
    func WebServiceCall()
    {
        
        /////Get method json
        let url = URL(string: "http://163.172.20.165/ImHereWebAPI/Api/VehicleDetails/190")
        let request = URLRequest(url: url!)
        let config = URLSessionConfiguration.default
        let session = URLSession(configuration: config)
        
        let task = session.dataTask(with: request, completionHandler: {(data, response, error) in
            if (data != nil){
                do{
                    self.dictData = try JSONSerialization.jsonObject(with: data!, options: []) as! NSArray
                    print(self.dictData)
                    self.tblvw .reloadData()
                    self.separateDataAndStoreToVC()
                }
                catch let error {
                    print("json error: \(error)")
                }
                
            }
            else{
                let alertController = UIAlertController(title: "Data Error", message: "Internet Problem ", preferredStyle: .alert)
                
                let defaultAction = UIAlertAction(title: "OK", style: .default, handler: nil)
                
                
                alertController.addAction(defaultAction)
                
                self.present(alertController, animated: true, completion: nil)
            }
            
            
        });
        
        task.resume()
        
    }
    func separateDataAndStoreToVC()
    {
        for i in 0..<dictData.count
        {
            let vc = searchVehicleData()
            vc.vehicleNumber = ((dictData[i] as! NSDictionary)["vnumber"] as! NSString ) as String
            vc.Address = ((dictData[i] as! NSDictionary)["Address"] as! NSString ) as String
            
            
            mainResult.add(vc)
            
        }
        tblvw.reloadData()
    }
    func updateSearchResults(for searchController: UISearchController)
    {
        
        let searchString = resultSearchController.searchBar.text
        
        if searchString == "" {
            searchResults = mainResult
            tblvw .reloadData()
        }
        else{
            let resultPredicate = NSPredicate(format: "vehicleNumber contains[c] %@", searchString!)
            searchResults = mainResult .filtered(using: resultPredicate) as NSArray
            tblvw .reloadData()
        }
    }
    func  searchBar(_ searchBar: UISearchBar, selectedScopeButtonIndexDidChange selectedScope: Int) {
        
        updateSearchResults(for: resultSearchController)
    }
    
}
