//
//  searchVehicleData.swift
//  searchBarSwif3
//
//  Created by iMac-meridian on 10/27/16.
//  Copyright © 2016 iMac-meridian. All rights reserved.
//

import UIKit

class searchVehicleData: NSObject {

    var vehicleNumber = String()
    var Address = String()
    
    
}
