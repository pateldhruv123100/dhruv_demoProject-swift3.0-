//
//  HomeVC.swift
//  IMHere24X7_Swift
//
//  Created by i mac meridian on 10/21/16.
//  Copyright © 2016 i mac meridian. All rights reserved.
//

import UIKit

class HomeVC: UIViewController {
    let appDelegate = UIApplication.shared.delegate as! AppDelegate
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func ExitBtn(_ sender: UIButton) {
        let alertController = UIAlertController(title: "Confirmation", message: "Do you want to exit?", preferredStyle: .alert)
        let okAction = UIAlertAction(title: "Yes", style: UIAlertActionStyle.default) {
            UIAlertAction in
         //   _ = self.navigationController?.popViewController(animated: true)
            let instagramHooks = "https://itunes.apple.com/in/app/truckbridge/id1079440971?mt=8"
            let instagramUrl = URL(string: instagramHooks)
            if UIApplication.shared.canOpenURL(instagramUrl! as URL)
            {
                UIApplication.shared.open(instagramUrl!)
                
            } else {
                //redirect to safari because the user doesn't have Instagram
                print("App not installed")
                UIApplication.shared.open(URL(string: "https://itunes.apple.com/in/app/instagram/id389801252?m")!)
            }
            NSLog("OK Pressed")
        }
        let cancelAction = UIAlertAction(title: "No", style: UIAlertActionStyle.cancel) {
            UIAlertAction in
            NSLog("Cancel Pressed")
        }
        alertController.addAction(okAction)
        alertController.addAction(cancelAction)
        self.present(alertController, animated: true, completion: nil)
    }
    @IBAction func callDirect(_ sender: AnyObject) {
        appDelegate.CallDirect()
    }
    

}
