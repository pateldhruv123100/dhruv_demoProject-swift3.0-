//
//  MapVC.swift
//  IMHere24X7_Swift
//
//  Created by i mac meridian on 10/27/16.
//  Copyright © 2016 i mac meridian. All rights reserved.
//

import UIKit
import GoogleMaps
import MBProgressHUD

class MapVC: UIViewController,GMSMapViewDelegate {
    var marker = GMSMarker()
    var mapView = GMSMapView()
   var listVCdetails = NSInteger()
    @IBOutlet weak var HeaderView: UIView!
   
    @IBOutlet weak var UImap: UIView!
    override func viewDidLoad() {
        super.viewDidLoad()
        self.WebService()
        _ = Timer.scheduledTimer(timeInterval: 45.00, target: self, selector: #selector(self.WebService), userInfo: nil, repeats: true);
      
        let camera = GMSCameraPosition.camera(withLatitude: 17.000, longitude: 80.000, zoom: 4.15, bearing: 0, viewingAngle: 30)
         mapView = GMSMapView.map(withFrame: self.view.frame, camera: camera)
        mapView.isMyLocationEnabled = true
        UImap .addSubview(mapView)
       self.view.addSubview(UImap)
        print(listVCdetails)
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // Web Service
    func WebService() -> Void {
        DispatchQueue.global(qos: .background).async {
           let UserID = (userDefult.string(forKey: "userId"))! as String
            let urlString = "\(RequestURL)VehicleDetails/\(UserID)"
            
            let url = URL(string: urlString)
            URLSession.shared.dataTask(with:url!, completionHandler: {(data, response, error) in
                if error != nil
                {
                    DispatchQueue.main.async {
                        let alert = UIAlertController(title: "Alert", message: "Server Error", preferredStyle: UIAlertControllerStyle.alert)
                        alert.addAction(UIAlertAction(title: "Okay", style: UIAlertActionStyle.default, handler: nil))
                        self.present(alert, animated: true, completion: nil)
                        MBProgressHUD.hide(for: self.view, animated: true)
                      //  print(error ?? <#default value#>)
                    }
                }
                else {
                    do {
                        
                        let parsedData = try JSONSerialization.jsonObject(with: data!, options: .allowFragments) as! NSArray
                        
                        print("data is" ,parsedData)
                     
                            for i in 0..<parsedData.count {
                         
                                let Latitude = ((parsedData[i] as! NSDictionary)["latitude"] as? NSString)!.doubleValue
                                
                                let Longitude = ((parsedData[i] as! NSDictionary)["longitude"] as? NSString)!.doubleValue
                                let VDetails = (parsedData[i] as! NSDictionary)["vnumber"] as! NSString
                                let intIgnition = (parsedData[i] as! NSDictionary)["ignition"] as! NSInteger
                                let intSpeed = (parsedData[i] as! NSDictionary)["speed"] as! NSString
                                
    DispatchQueue.main.async {
                                    
                            let position = CLLocationCoordinate2D(latitude: Latitude, longitude: Longitude)
                            self.marker = GMSMarker(position: position)
                            self.marker.title = ("\(VDetails) -->")
                            self.marker.tracksViewChanges = true
                            self.marker.appearAnimation = kGMSMarkerAnimationPop
                            self.marker.map = self.mapView as GMSMapView?
        
                              if intIgnition == 1 && intSpeed == "0" {
                                   self.marker.icon =  UIImage(named: "car_Blue")
                                 }
                             else if intIgnition == 0 {
                                   self.marker.icon =  UIImage(named: "car_Red")
                                 }
                             else if intIgnition == 1 {
                                   self.marker.icon =  UIImage(named: "car_Green")
                                }
                            }
                    }
                   
                    }
                    catch let error as NSError
                    {
                        DispatchQueue.main.async
                            {
                            let alert = UIAlertController(title: "Alert", message: "Server Error", preferredStyle: UIAlertControllerStyle.alert)
                            alert.addAction(UIAlertAction(title: "Okay", style: UIAlertActionStyle.default, handler: nil))
                            self.present(alert, animated: true, completion: nil)
                            MBProgressHUD.hide(for: self.view, animated: true)
                            print(error)
                           }
                        
                    }
                }
                
            }).resume()
        }
    }
    // Web Service Finish
    
}
