//
//  ViewController.swift
//  IMHere24X7_Swift
//
//  Created by i mac meridian on 10/20/16.
//  Copyright © 2016 i mac meridian. All rights reserved.
//

import UIKit
import PasswordTextField
import MBProgressHUD

class ViewController: UIViewController,UIGestureRecognizerDelegate,UITextFieldDelegate
 {
    let appDelegate = UIApplication.shared.delegate as! AppDelegate
    @IBOutlet weak var Lbl: UILabel!
    @IBOutlet weak var CheckBox: UIButton!
    @IBOutlet weak var TxtUserID: UITextField!
    @IBOutlet weak var TxtPassWord: PasswordTextField!
    @IBOutlet weak var ImguserID: UIImageView!
    @IBOutlet weak var btnlogin: UIButton!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
       TxtUserID.layer.cornerRadius = 5
        Lbl .sizeToFit()
        btnlogin.titleLabel!.adjustsFontSizeToFitWidth = true;
        
        let paddingUserID = UIView(frame:CGRect(x: 0, y: 0, width: TxtUserID.frame.height + 15, height:TxtUserID.frame.height))
        TxtUserID.leftView = paddingUserID
        TxtUserID.leftViewMode = UITextFieldViewMode.always
         let paddingPassWord = UIView(frame:CGRect(x: 0, y: 0, width: TxtPassWord.frame.height + 15, height:TxtUserID.frame.height))
        TxtPassWord.leftView = paddingPassWord
        TxtPassWord.leftViewMode = UITextFieldViewMode.always
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
//next button should work
    func textFieldShouldReturn(_ textField: UITextField) -> Bool{
        
        if (textField === TxtUserID)
        {
           
            TxtPassWord.becomeFirstResponder()
        }
        else if (textField === TxtPassWord)
        {
            textField .resignFirstResponder()
            
        }
        return true
    }
//next button should work Finish
 
    
    @IBAction func btnLogin(_ sender: UIButton) {
        // Internet Connection
        let startHUD = MBProgressHUD.showAdded(to: self.view, animated: true)
        startHUD.label.text = "Loading..."
        if TxtUserID.text == ""
        {
            let alert = UIAlertController(title: "ALERT", message: "PLZ Enter ID", preferredStyle: UIAlertControllerStyle.alert)
            alert.addAction(UIAlertAction(title: "Okay", style: UIAlertActionStyle.default, handler: nil))
            MBProgressHUD.hide(for: self.view, animated: true)
            self.present(alert, animated: true, completion: nil)
        }
        else if TxtPassWord.text == ""
        {
            let alert = UIAlertController(title: "ALERT", message: "PLZ Enter passWord", preferredStyle: UIAlertControllerStyle.alert)
            alert.addAction(UIAlertAction(title: "Okay", style: UIAlertActionStyle.default, handler: nil))
            MBProgressHUD.hide(for: self.view, animated: true)
            self.present(alert, animated: true, completion: nil)

        }
        else
        {
        
            if Reachability.isConnectedToNetwork() == true {
               print("Internet connection OK")
                if (self.CheckBox.tag==1)
                {
                    userDefult .set(TxtPassWord.text, forKey: "UserPassWord")
                    userDefult .set(TxtUserID.text, forKey: "UserName")
                    userDefult .set(true, forKey: "RememberKey")
                    
                    userDefult .synchronize()
                }
                else
                {
                    userDefult .removeObject(forKey: "UserPassWord")
                    userDefult .removeObject(forKey: "UserName")
                    userDefult .set(false, forKey: "RememberKey")
                    userDefult .set(false, forKey: "userId")
                    userDefult.synchronize()
                }
                  self.WebService()
               }
            else
            {
               let alert = UIAlertController(title: nil, message: "Internet Connection Required", preferredStyle: UIAlertControllerStyle.alert)
               alert.addAction(UIAlertAction(title: "Okay", style: UIAlertActionStyle.default, handler: nil))
               self.present(alert, animated: true, completion: nil)
               print("Internet connection FAILED")
             }
        }
        
      
        
    }
    
// Check Box Work
    override func viewWillAppear(_ animated: Bool) {
        self.view .isUserInteractionEnabled = true
        self.CheckBox.tag=0
        self.CheckBox .setBackgroundImage(UIImage(named: "cb_glossy_off.png"), for:  UIControlState())
        if (userDefult.bool(forKey: "RememberKey"))
        {
            
            self.CheckBox.tag=1
            self.CheckBox .setBackgroundImage(UIImage(named: "cb_glossy_on.png"), for:  UIControlState())
            self.TxtUserID.text = userDefult.string(forKey: "UserName")
            self.TxtPassWord.text = userDefult.string(forKey: "UserPassWord")
        }
        else
        {
            TxtUserID.text = ""
            TxtPassWord.text = ""
        }
    }

    @IBAction func BtnCheckBox(_ sender: UIButton) {
        
        let Btn = sender as UIButton
        if (Btn.tag==0) {
            Btn.tag=1
            Btn.setBackgroundImage(UIImage(named: "cb_glossy_on.png"), for: UIControlState())
        }
        else
        {
            Btn.tag=0
            Btn.setBackgroundImage(UIImage(named: "cb_glossy_off.png"), for: UIControlState())
        }
    }
// Check Box Work Finish
   // Web Service
    func WebService() -> Void {
        DispatchQueue.global(qos: .background).async {
        let PassWord = self.TxtPassWord.text!
        let myString = self.TxtUserID.text!
        let UserID = myString.trimmingCharacters(in: CharacterSet.whitespacesAndNewlines)
         
        let urlString = "\(RequestURL)Login/\(UserID)/\(PassWord)"
        
        let url = URL(string: urlString)
        URLSession.shared.dataTask(with:url!, completionHandler: {(data, response, error) in
            if error != nil
            {
                DispatchQueue.main.async {
                    let alert = UIAlertController(title: "Alert", message: "Please Enter Valid UserID Or PassWord", preferredStyle: UIAlertControllerStyle.alert)
                    alert.addAction(UIAlertAction(title: "Okay", style: UIAlertActionStyle.default, handler: nil))
                    self.present(alert, animated: true, completion: nil)
                    MBProgressHUD.hide(for: self.view, animated: true)
                  //  print(error ?? <#default value#>)
                }
            }
            else {
                do {
                    
                    let parsedData = try JSONSerialization.jsonObject(with: data!, options: .allowFragments) as! [String:Any]
                    print("data is" ,parsedData)
                    let currentConditions = parsedData["Message"] as!String
                   
                    if (currentConditions == "Success")
                    {
                        
                         let arrVehicleDetail = parsedData["vehicleDetails"] as!NSArray
                         print(arrVehicleDetail)
                        var arrVehicleNo:[Any] = []
                         var arrVehicleID:[Any] = []
                         var arrTrackerName:[Any] = []
                       
                        for i in 0..<arrVehicleDetail.count {
                            
                            arrVehicleNo.append((arrVehicleDetail[i] as! NSDictionary)["vnumber"]! as Any )
                            arrVehicleID.append((arrVehicleDetail[i] as! NSDictionary)["VehicleId"]! as Any )
                            arrTrackerName.append((arrVehicleDetail[i] as! NSDictionary)["trackername"]! as Any )
                        }
                        userDefult .set(arrVehicleNo, forKey: "VehicleNo")
                        userDefult .set(arrVehicleID, forKey: "VehicleID")
                        userDefult .set(arrTrackerName, forKey: "TrackerName")
                        userDefult .set((parsedData["loginModel"] as!NSDictionary) ["Customerid"]! as Any , forKey: "userId")
                        //
                        DispatchQueue.main.async {
                        let storyboard = UIStoryboard(name: "Main", bundle: nil)
                        let vc = storyboard.instantiateViewController(withIdentifier: "HomeVC") as! HomeVC
                        self.navigationController?.pushViewController(vc,animated: true)
                        print("thai gyu")
                         MBProgressHUD.hide(for: self.view, animated: true)
                        }
                    }
                    else
                    {
                       DispatchQueue.main.async {
                        let alert = UIAlertController(title: "Alert", message: "Please Enter Valid UserID Or PassWord", preferredStyle: UIAlertControllerStyle.alert)
                        alert.addAction(UIAlertAction(title: "Okay", style: UIAlertActionStyle.default, handler: nil))
                        self.present(alert, animated: true, completion: nil)
                        MBProgressHUD.hide(for: self.view, animated: true)
                             }
                    }
                             }
                catch let error as NSError
                {
                    DispatchQueue.main.async {
                        let alert = UIAlertController(title: "Alert", message: "Please Enter Valid UserID Or PassWord", preferredStyle: UIAlertControllerStyle.alert)
                        alert.addAction(UIAlertAction(title: "Okay", style: UIAlertActionStyle.default, handler: nil))
                        self.present(alert, animated: true, completion: nil)
                        MBProgressHUD.hide(for: self.view, animated: true)
                        print(error)
                    }

                }
            }
            
        }).resume()
        }
    }
    // Web Service Finish
  
   
}

