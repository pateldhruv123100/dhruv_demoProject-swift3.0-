//
//  profileVC.swift
//  IMHere24X7_Swift
//
//  Created by i mac meridian on 11/11/16.
//  Copyright © 2016 i mac meridian. All rights reserved.
//

import UIKit

class profileVC: UIViewController {
    var arr : NSMutableArray = ["Pencil", "Eraser", "Notebook"]
    var barr : Array = ["Pencil", "Eraser", "Notebook"]
    

    override func viewDidLoad() {
        super.viewDidLoad()
        self.postWebService()
        arr[2] = "Pen"
        barr[2] = "Pen"
        print (arr)
        print(barr)
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    func postWebService()
    {
        DispatchQueue.global(qos: .background).async {
            
            let img : UIImage = UIImage(named:"LOGO")!
            ////////////////////////    post method json
            let data = UIImagePNGRepresentation(img)
            //        let base64string :String = (data?.base64EncodedStringWithOptions(NSDataBase64EncodingOptions(rawValue: 0)))!
            let base64string:NSString = data!.base64EncodedString(options: .lineLength64Characters) as NSString
            
            
            let DictData :NSDictionary = ["CustomerId":190,"photoArray":base64string]
            print(DictData)
            
            var request = URLRequest(url: URL(string: "http://163.172.20.165//ImHereWebAPI/Api/ImageUpload/")!)
            let session = URLSession.shared
            request.httpMethod = "POST"
            request.addValue("application/json", forHTTPHeaderField: "Content-Type")
            request.addValue("application/json", forHTTPHeaderField: "Accept")
            request.httpBody = try! JSONSerialization.data(withJSONObject: DictData, options: [])
            
            
            let task = session.dataTask(with: request, completionHandler: { data, response, error in
                guard data != nil else {
                    print("no data found: \(error)")
                    return
                }
                DispatchQueue.main.async{
                    do {
                        if let json = try JSONSerialization.jsonObject(with: data!, options: []) as? NSDictionary {
                            print(json)
                        }
                        else {
                            let jsonStr = NSString(data: data!, encoding: String.Encoding.utf8.rawValue)    // No error thrown, but not NSDictionary
                            print("Error could not parse JSON: \(jsonStr)")
                        }
                    } catch let parseError {
                        print(parseError)                                                          // Log the error thrown by `JSONObjectWithData`
                        let jsonStr = NSString(data: data!, encoding: String.Encoding.utf8.rawValue)
                        print("Error could not parse JSON: '\(jsonStr)'")
                    }
                }
            })
            
            task.resume()
        }
        
    }
    
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
